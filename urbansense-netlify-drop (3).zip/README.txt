URBANSENSE — NETLIFY DROP DEMO

DEPLOY
1. Extract this ZIP.
2. Open https://app.netlify.com/drop
3. Drag the extracted folder (urbansense-netlify-drop) onto Netlify Drop.
4. Wait for deployment, then open the generated site URL.

INCLUDED
- Responsive UrbanSense reporting interface
- Browser live camera capture
- Optional browser geolocation
- Hazard category and description validation
- Locally generated demo receipt

IMPORTANT LIMITATIONS
This is a static frontend demo. It does not run main.py or urban_sense_ai.py.
Reports are not uploaded to a server, saved to a database, reviewed by real AI,
sent to a municipality, or shared with other users. The receipt is generated
in the browser for demonstration only. Camera and location generally require
HTTPS; Netlify provides HTTPS on deployed sites.
